<?

//TODO: 
//	- Get params of order and save it to DB
// 	- Check params for validation
//	- Copy&Rename MQL CodePage of AreaFiftyOne with order params
//	- Set license params in the new file
//	- Generate new .ex4
//	- Send E-Mail to customer and me
//	- Set info in DB, that product was sent

?>