<?php




$stringToReplace = "
bool trial_lic=$trial;
datetime expiryDate=D'$trialExpiryDate 00:00';
bool rent_lic=$rent;
datetime rentExpiryDate=D'$rentExpiryDate 00:00';
int rentAccountNumber=$rentAccountNumber;
string rentCustomerName=\"$rentCustomerName\";
";
?>